# Pioneer Property Management – Website

Static website (HTML + Tailwind CDN). No build step needed.

## Pages
| File | Page |
|---|---|
| index.html | Home |
| about.html | About Us |
| services.html | Services |
| value-solutions.html | Value Solutions |
| leadership.html | Leadership |
| portfolio.html | Portfolio |
| contact.html | Contact Us |
| privacy.html / terms.html / 404.html | Legal + error page |

## Deploy on GitHub Pages
1. Create a repo and upload ALL files in this folder (keep the `assets/` folder and `.nojekyll`).
2. Repo > Settings > Pages > Source: "Deploy from a branch" > Branch: `main` / `(root)` > Save.
3. Site goes live at `https://<username>.github.io/<repo>/` in 1-2 minutes.

## Notes
- Contact / audit forms open WhatsApp (016-918 0008) with the filled details, since GitHub Pages has no server. To receive emails instead, use Formspree or Web3Forms.
- Logo, founder photo and licence certificate are in `assets/img/`.
- Building/stock photos load from Google-hosted URLs. For long-term reliability, replace them with your own photos in `assets/img/`.
