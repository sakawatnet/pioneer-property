(function(){
  var WA='60169180008';
  // ---- Mobile menu
  function initMenu(){
    var header=document.querySelector('header'); if(!header) return;
    var nav=header.querySelector('nav'); var bar=header.querySelector('.h-20'); if(!nav||!bar) return;
    var right=bar.lastElementChild;
    var btn=document.createElement('button');
    btn.type='button'; btn.setAttribute('aria-label','Toggle menu'); btn.setAttribute('aria-expanded','false');
    btn.className='xl:hidden ml-2 inline-flex items-center justify-center w-10 h-10 rounded-lg text-primary hover:bg-surface-container-high';
    btn.innerHTML='<span class="material-symbols-outlined">menu</span>';
    right.appendChild(btn);
    var panel=document.createElement('div');
    panel.id='mobile-menu';
    panel.className='hidden xl:hidden bg-surface border-t border-outline-variant/30 shadow-lg px-margin-mobile py-space-md';
    var inner=document.createElement('div'); inner.className='flex flex-col gap-1';
    nav.querySelectorAll('a').forEach(function(a){
      var c=a.cloneNode(true); c.className='px-4 py-3 rounded-lg font-label-md text-label-md '+(a.getAttribute('aria-current')?'bg-surface-container text-primary':'text-on-surface-variant hover:bg-surface-container-high');
      inner.appendChild(c);
    });
    var tel=document.createElement('a'); tel.href='tel:0169180008'; tel.className='mt-2 px-4 py-3 rounded-lg bg-primary-container text-on-primary text-center font-label-md text-label-md'; tel.textContent='Call 016-918 0008';
    inner.appendChild(tel); panel.appendChild(inner); header.appendChild(panel);
    btn.addEventListener('click',function(){
      var open=panel.classList.toggle('hidden')===false;
      btn.setAttribute('aria-expanded',open);
      btn.firstChild.textContent=open?'close':'menu';
    });
  }
  // ---- Forms -> WhatsApp (static hosting has no backend)
  function initForms(){
    [['proposal-form','success-state','Proposal Request'],['audit-form','audit-success','Audit Inspection Request']].forEach(function(cfg){
      var f=document.getElementById(cfg[0]); if(!f) return;
      f.addEventListener('submit',function(e){
        e.preventDefault();
        var lines=['*'+cfg[2]+' (website)*'], services=[];
        f.querySelectorAll('input,select,textarea').forEach(function(el){
          if(el.type==='checkbox'){
            if(el.checked){var l=el.closest('label'); if(l) services.push(l.textContent.replace(/\s+/g,' ').trim());}
            return;
          }
          var v=(el.value||'').trim(); if(!v) return;
          var wrap=el.parentElement, lab=wrap&&wrap.querySelector('label');
          var name=lab?lab.textContent.replace(/\*/g,'').replace(/\s+/g,' ').trim():(el.placeholder||el.id||'Field');
          lines.push(name+': '+v);
        });
        if(services.length) lines.push('Services: '+services.join('; '));
        window.open('https://wa.me/'+WA+'?text='+encodeURIComponent(lines.join('\n')),'_blank','noopener');
        var ok=document.getElementById(cfg[1]); if(ok) ok.classList.remove('hidden');
        f.classList.add('hidden');
      });
    });
  }
  // ---- Image fallback
  function initImgs(){
    document.querySelectorAll('img').forEach(function(img){
      img.addEventListener('error',function(){ if(!img.classList.contains('img-fallback')){img.classList.add('img-fallback'); img.removeAttribute('srcset');} },{once:true});
    });
  }
  document.addEventListener('DOMContentLoaded',function(){initMenu();initForms();initImgs();});
})();
